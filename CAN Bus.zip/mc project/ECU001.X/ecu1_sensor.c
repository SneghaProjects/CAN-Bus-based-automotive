#include "ecu1_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "uart.h"
#include<stdint.h>
uint8_t pos;
uint16_t get_speed()
{
    // Implement the speed function
    uint8_t spd=read_adc(CHANNEL4)/10.33;
    can_transmit(SPEED_MSG_ID ,&spd,sizeof(spd));

}

unsigned char get_gear_pos()
{
    // Implement the gear function
    unsigned char key=read_digital_keypad(STATE_CHANGE);
    if((key==SWITCH1) && (pos<5))
    {
        pos++;
    }
    else if((key==SWITCH2)&& (pos>0))
    {
        pos--;
    }
    else if(key==SWITCH3)
    {
        pos=6;
    }
    can_transmit(GEAR_MSG_ID, &pos ,sizeof(pos));
}