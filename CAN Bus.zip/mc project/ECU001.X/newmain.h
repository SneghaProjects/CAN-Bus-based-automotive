/*
 * File:   newmain.h
 * Author: snegh
 *
 * Created on 18 June, 2025, 4:20 PM
 */


#include <xc.h>

void main(void) {
    return;
}
