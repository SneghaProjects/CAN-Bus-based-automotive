#include "adc.h"
#include "can.h"
#include "ecu1_sensor.h"
#include "msg_id.h"
#include "uart.h"

int main()
{
    //Call the functions
    //init congig
    //while loop inside sensor need to be called
    init_adc();
    init_digital_keypad();
    init_can();
    while(1)
    {
         get_speed();
         get_gear_pos();
    }
}