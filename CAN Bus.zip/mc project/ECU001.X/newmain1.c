/*
 * File:   newmain1.c
 * Author: snegh
 *
 * Created on 18 June, 2025, 4:21 PM
 */


#include <xc.h>

void main(void) {
    return;
}
