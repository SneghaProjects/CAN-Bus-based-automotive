#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "uart.h"

int main()
{
    //call the functions
    init_adc();
    init_can();
    init_digital_keypad();
    init_uart();
  
    while(1)
    {
        get_rpm();
        get_engine_temp();
        process_indicator();
    }
}
