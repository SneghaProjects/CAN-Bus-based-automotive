#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "uart.h"
uint8_t rpm,key;
unsigned short res;
uint16_t get_rpm()
{
    //Implement the rpm function
    res=read_adc(CHANNEL4);
    rpm=res/4;
    can_transmit(RPM_MSG_ID, &rpm,1);
}

uint16_t get_engine_temp()
{
    //Implement the engine temperature function
}

IndicatorStatus process_indicator()
{
    //Implement the indicator function
    key=read_digital_keypad(STATE_CHANGE);
    can_transmit(INDICATOR_MSG_ID, &key,1);
}