#include <xc.h>
#include <string.h>
#include "message_handler.h"
#include "msg_id.h"
#include "can.h"
#include "clcd.h"


volatile unsigned char led_state = LED_OFF, status = e_ind_off;

uint16_t msg_id;
unsigned int count=0;
uint8_t data,len,key,blink;
unsigned char gr[7][3]={"GN","G1","G2","G3","G4","GR","C_"};
void handle_speed_data(uint8_t *data, uint8_t len)
{
    //Implement the speed function
     clcd_putch(((*data/10)+48),LINE2(0));
    clcd_putch(((*data%10)+48),LINE2(1));
}

void handle_gear_data(uint8_t *data, uint8_t len) 
{
    //Implement the gear function
    clcd_print(gr[*data],LINE2(3));
}

void handle_rpm_data(uint8_t *data, uint8_t len) 
{
    //Implement the rpm function
   unsigned int rpm = *data *23;
    clcd_putch((rpm/1000)+48,LINE2(6));
    clcd_putch(((rpm/100)%10)+48,LINE2(7));
     clcd_putch(((rpm/10)%10)+48,LINE2(8));
      clcd_putch((rpm%10)+48,LINE2(9));
}

void handle_engine_temp_data(uint8_t *temp, uint8_t len) 
{
    //Implement the temperature function
    clcd_putch(((*temp/10)+48),LINE2(11));
    clcd_putch(((*temp%10)+48),LINE2(12));
    
}

void handle_indicator_data(uint8_t *data, uint8_t len) 
{
    //Implement the indicator function
    key=*data;
    if(blink)
    {
        if(key==1)
        {
            RB0=!RB0;
            RB1=!RB1;
            clcd_print("<-",LINE2(14));
        }
        else if(key==3)
        {
            RB6=!RB6;
            RB7=!RB7;
            clcd_print("->",LINE2(14));
        }
        else if(key==2)
        {
            PORTB=0X00;
            clcd_print("  ",LINE2(14));
        }
    }
}

void process_canbus_data() 
{   
    //process the CAN bus data
    can_receive(&msg_id,&data,&len);
    if(msg_id==SPEED_MSG_ID)
    handle_speed_data(&data,1);
    else if(msg_id==GEAR_MSG_ID)
    handle_gear_data(&data,1);
    else if(msg_id==ENG_TEMP_MSG_ID)
    handle_engine_temp_data(&data,1);
    else if(msg_id==RPM_MSG_ID)
    handle_rpm_data(&data,1);
    else if(msg_id==INDICATOR_MSG_ID)
    handle_indicator_data(&data,1);
}  

void __interrupt() isr(void)
{
    if(TMR0IF)
    {
        TMR0=TMR0+8;
        if(count++ == 20000)
        {
            count=0;
            blink=!blink;
        }
        TMR0IF=0;
    }
}